
                                                                                                    
             7NMM8                                         INMMD?                                   
          8MMMMMMMMMM?           NMMMMMMMMMMMM          ?MNMMMMMMMM         MMMMMMMMMMMMMMMMMM      
        DMMMMMMMMMMMMMM          MMMMMMMMMMMMM         MMMMMMMMMMMMMN       MMMMMMMMMMMMMMMMM$      
       OMMMMMMMMMMMMMMMM         MMMMMMMMMMMMM        MMMMMMMMMMMMMMMM      MMMMMMMMMMMMMMMMM       
       MMMMMMMMMMMMMMMMMM       OMMMMMMMMMMMMM        MMMMMM?  OMMMMMM      MMMMMMMMMMMMMMMM        
      7MMMMMMMMZMMMMMMMMM       MMMMMMMMMMMMMM        MMMMMM    MMMMMM      MMMMMMMMMMMMMMMM        
      OMMMMMMM   MMMMMMMM       MMMMMMMZ :            MMMMMMO  DMMMMMM              MMMMMMM7        
      ?MMMMMMM  $MMMMMMMM      $MMMMMMMMMMM           $MMMMMMMMMMMMMM              NMMMMMMM         
       MMMMMMD  MMMMMMMMO      NMMMMMMMMMMMMN         ?MMMMMMMMMMMMMM              MMMMMMMN         
       ?MMMMO  MMMMMMMMD       MMMMMMMMMMMMMMM       7MMMMMMMMMMMMMMMM            OMMMMMMM          
         MMN  MMMMMMMMM               MMMMMMMMZ      MMMMMMMD INMMMMMMM          ?MMMMMMMM          
             OMMMMMMMM                :MMMMMMMN     ZMNMMMM     7MMMMMM          NMMMMMMN7          
            8MMMMMMMMI                :MMMMMMMM     8MMMMMM      NMMMMMI         MMMMMMMM           
            MMMMMMMMMMMMNI    $D      MMMMMMMMM     $MMMMMM      MMMMMM         NMMMMMMM            
           MMMMMMMMMMMMMMI    IMMMMMMMMMMMMMMMI      MMMMMMMM$ZMMMMMMMM         MMMMMMMM            
          MMMMMMMMMMMMMMMI    IMMMMMMMMMMMMMMN       7NMMMMMMMMMMMMMMM         NMMMMMMM7            
         NNMMMMMMMMMMMMMMI    IMMMMMMMMMMMMMN         7MMMMMMMMMMMMMM          MMMMMMMM             
       :MMMMMMMMMMMMMMMMMI     $MMMMMMMMMM               MMMMMMMMMD           MMMMMMMM8             
                                                                                                    
     MMMMMM?                                             8MMMN$                                     
     MMMMMMMMM     NM?                                  MMMOZMMM                                    
     MM      MMO   ZD                                  MN      MN               MM                  
     MM       MM   8D     ZO8D88      ZM7    ZNMMD    IMM     7M8     NMMN$     MM8888   IO8888     
     MM       MM7  MM   MMMMMMMN   ZMMNMM  NMMM8MMMM  IMM ZZ8NMM    NMMDDMMMD   MMMMMM DMMMMMMM     
     MM       DMZ  MM  ?MM        OMM     DMM:    NMM IMMIMNMMMNI  MMD     8M$  MM     MM$          
     MM       MM   MM   ?MMMMM   ?NM      MM?      MM IMM      MMN MM       MN  MM      MMMMMO      
     MM      DMN   MM       OMMM  NM      MMO      MM IMM      ZMM MM       MM  MM         ZMMMI    
     MM     MMM    MM         NMZ 8MM     ?MM?    MMZ IMM      MMZ:NMM     MM   MM            MM    
     MM MMMNMZ     MM  7MMMMMMMM   8MMMMM  $MMMMMMMD  7MMINMMMMMI   ZMMMMMMM    DMMMMM MMMMMMMM7    
                                                                                                    
                                                                                                    
                                                                                                    
                                                                                                  
# 2017-Steamworks 
Welcome to the DiscoBots code repository for the 2017 First Robotics Competition game: Steamworks!  
Contributors:  
Mason Cole  
Gilbert Martinez  
William Bittner
